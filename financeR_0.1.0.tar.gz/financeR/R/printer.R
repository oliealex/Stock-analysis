printer <- function(r,x,y) {
  print(paste0("x =", x))
}
